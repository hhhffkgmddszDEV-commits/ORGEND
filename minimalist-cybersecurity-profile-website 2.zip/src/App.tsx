import { useState, useEffect, useRef, useCallback } from 'react';
import './index.css';

type Page = 'entry' | 'home' | 'kernel' | 'martyr';

/* ─── GLITCH TRANSITION ─── */
function useGlitchTransition() {
  const [isGlitching, setIsGlitching] = useState(false);
  const [stripes, setStripes] = useState<{ top: string; height: string; opacity: number; offset: string }[]>([]);
  const resolve = useRef<() => void>(() => {});

  const runGlitch = useCallback((): Promise<void> => {
    return new Promise((res) => {
      resolve.current = res;
      setIsGlitching(true);

      const generated = Array.from({ length: 18 }, () => ({
        top: `${Math.random() * 100}%`,
        height: `${Math.random() * 8 + 1}px`,
        opacity: Math.random() * 0.9 + 0.1,
        offset: `${(Math.random() - 0.5) * 20}px`,
      }));
      setStripes(generated);

      setTimeout(() => {
        setIsGlitching(false);
        res();
      }, 700);
    });
  }, []);

  return { isGlitching, stripes, runGlitch };
}

/* ─── ENTRY SCREEN ─── */
function EntryScreen({ onEnter }: { onEnter: () => void }) {
  const [typed, setTyped] = useState('');
  const full = 'ORG-END';

  useEffect(() => {
    let i = 0;
    const timer = setInterval(() => {
      i++;
      setTyped(full.slice(0, i));
      if (i >= full.length) clearInterval(timer);
    }, 120);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="entry-screen">
      {/* Top classification */}
      <div style={{
        position: 'absolute',
        top: '1.5rem',
        left: '50%',
        transform: 'translateX(-50%)',
        fontFamily: 'var(--font-mono)',
        fontSize: '0.6rem',
        letterSpacing: '0.45em',
        color: '#222',
        textTransform: 'uppercase',
        whiteSpace: 'nowrap',
      }}>
        classified // level-5 clearance required
      </div>

      {/* Corner decorations */}
      <div style={{ position: 'absolute', top: '2rem', left: '2rem', width: '30px', height: '30px', borderTop: '1px solid #222', borderLeft: '1px solid #222' }} />
      <div style={{ position: 'absolute', top: '2rem', right: '2rem', width: '30px', height: '30px', borderTop: '1px solid #222', borderRight: '1px solid #222' }} />
      <div style={{ position: 'absolute', bottom: '2rem', left: '2rem', width: '30px', height: '30px', borderBottom: '1px solid #222', borderLeft: '1px solid #222' }} />
      <div style={{ position: 'absolute', bottom: '2rem', right: '2rem', width: '30px', height: '30px', borderBottom: '1px solid #222', borderRight: '1px solid #222' }} />

      {/* Logo */}
      <div className="entry-logo flicker">
        {typed}
        <span style={{ opacity: Math.random() > 0.5 ? 1 : 0.3, transition: 'opacity 0.1s', color: '#444' }}>_</span>
      </div>

      <div className="entry-subtitle">elite cyber operations collective</div>

      {/* Status lines */}
      <div style={{ marginBottom: '2.5rem', display: 'flex', flexDirection: 'column', gap: '0.3rem', alignItems: 'center' }}>
        {['NETWORK_SECURE', 'IDENTITY_MASKED', 'ENCRYPTION_ACTIVE'].map((s, i) => (
          <div key={s} style={{
            fontFamily: 'var(--font-mono)',
            fontSize: '0.6rem',
            letterSpacing: '0.3em',
            color: '#222',
            textTransform: 'uppercase',
            animationDelay: `${i * 0.4}s`,
          }}>
            <span className="status-dot" style={{ animationDelay: `${i * 0.5}s` }} />
            {s}
          </div>
        ))}
      </div>

      <button className="entry-btn" onClick={onEnter}>
        [ ENTER ]
      </button>

      <div className="entry-scan-line" />

      <div style={{
        position: 'absolute',
        bottom: '1.5rem',
        right: '2rem',
        fontFamily: 'var(--font-mono)',
        fontSize: '0.55rem',
        letterSpacing: '0.25em',
        color: '#1a1a1a',
        textTransform: 'uppercase',
      }}>
        v2.4.1 // build stable
      </div>
    </div>
  );
}

/* ─── NAV BAR ─── */
function NavBar({ onHome }: { onHome: () => void }) {
  return (
    <nav className="nav-bar">
      <button
        onClick={onHome}
        style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}
      >
        <span className="nav-logo">ORG<span style={{ color: '#333' }}>-</span>END</span>
      </button>
      <div style={{ display: 'flex', alignItems: 'center', gap: '2rem' }}>
        <span className="nav-tag">
          <span className="status-dot" style={{ width: '5px', height: '5px', marginRight: '0.4rem' }} />
          ops active
        </span>
        <span className="nav-tag" style={{ display: 'none' }}>2026</span>
      </div>
    </nav>
  );
}

/* ─── HOME PAGE ─── */
function HomePage({ onSelect }: { onSelect: (p: 'kernel' | 'martyr') => void }) {
  return (
    <div className="main-layout page-enter">
      <NavBar onHome={() => {}} />

      <main className="home-section">
        <p className="home-heading">// select operative //</p>

        <div className="cards-container">
          {/* KERNEL CARD */}
          <div className="profile-card" onClick={() => onSelect('kernel')}>
            <div className="card-glow" />
            <div className="card-img-wrap">
              <img
                src="https://i.ibb.co/gL6mrj5Q/8-AE04-C8-D-4-F60-4909-9-EA1-B13253-EDD212.png"
                alt="Kernel"
              />
              <div className="card-img-overlay" />
            </div>
            <div className="card-body">
              <div className="card-id">ID::0x01 // OPERATIVE</div>
              <div className="card-name">Kernel</div>
              <div className="card-role">zero-day researcher // elite threat actor</div>
            </div>
            <div className="card-corner">access</div>
          </div>

          {/* MARTYR CARD */}
          <div className="profile-card" onClick={() => onSelect('martyr')}>
            <div className="card-glow" />
            <div className="card-img-wrap">
              <img
                src="https://i.ibb.co/Kpbp6mkP/IMG-9150.jpg"
                alt="Martyr"
              />
              <div className="card-img-overlay" />
            </div>
            <div className="card-body">
              <div className="card-id">ID::0x02 // OPERATIVE</div>
              <div className="card-name">Martyr</div>
              <div className="card-role">penetration tester // network specialist</div>
            </div>
            <div className="card-corner">access</div>
          </div>
        </div>

        {/* Bottom decorative row */}
        <div style={{
          marginTop: '2.5rem',
          display: 'flex',
          alignItems: 'center',
          gap: '1.5rem',
          opacity: 0.3,
        }}>
          <div style={{ width: '60px', height: '1px', background: '#fff' }} />
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.6rem', letterSpacing: '0.4em', color: '#fff', textTransform: 'uppercase' }}>
            2 operatives online
          </span>
          <div style={{ width: '60px', height: '1px', background: '#fff' }} />
        </div>
      </main>

      <footer className="site-footer">
        <span className="footer-text">© ORG-END // all rights reserved</span>
        <span className="footer-text">unauthorized access will be traced</span>
      </footer>
    </div>
  );
}

/* ─── LEVEL BAR ─── */
function LevelBar({ label, value, delay = 0 }: { label: string; value: number; delay?: number }) {
  const [width, setWidth] = useState(0);

  useEffect(() => {
    const t = setTimeout(() => setWidth(value), delay + 200);
    return () => clearTimeout(t);
  }, [value, delay]);

  return (
    <div className="level-bar-wrap">
      <div className="level-bar-label">
        <span>{label}</span>
        <span>{value}%</span>
      </div>
      <div className="level-bar-track">
        <div className="level-bar-fill" style={{ width: `${width}%` }} />
      </div>
    </div>
  );
}

/* ─── KERNEL PROFILE ─── */
function KernelPage({ onBack }: { onBack: () => void }) {
  return (
    <div className="profile-page page-enter">
      <NavBar onHome={onBack} />

      <div className="profile-hero">
        <div className="profile-img-wrap">
          <img
            src="https://i.ibb.co/gL6mrj5Q/8-AE04-C8-D-4-F60-4909-9-EA1-B13253-EDD212.png"
            alt="Kernel"
          />
        </div>

        <div className="profile-hero-text">
          <div className="profile-hero-id">// operative ID::0x01 — classification: APEX</div>
          <div className="profile-hero-name">Kernel</div>
          <div className="profile-hero-tagline">
            <span className="status-dot" />
            zero-day researcher &amp; advanced persistent threat specialist
          </div>
          <p className="profile-hero-desc">
            <span>Kernel</span> operates at the bleeding edge of offensive security. Specialized in kernel-level exploitation,
            advanced persistent threat development, and full-spectrum network infiltration.
            Known for discovering critical zero-days in major operating systems and bypassing
            hardened enterprise security infrastructure. An architect of{' '}
            <span>ORG-END</span>'s most classified operations.
          </p>

          <a
            href="https://www.tiktok.com/@k3rnel0?_r=1&_t=ZN-968WBnVlCNy"
            target="_blank"
            rel="noopener noreferrer"
            className="contact-btn"
          >
            <span>⬡</span> Contact Kernel
          </a>
        </div>
      </div>

      <div className="profile-content">

        {/* Expertise */}
        <section>
          <div className="section-label">// domains of expertise</div>
          <div className="skill-grid">
            {[
              'Kernel Exploitation',
              'Zero-Day Research',
              'Malware Development',
              'APT Operations',
              'Reverse Engineering',
              'Privilege Escalation',
              'Rootkit Development',
              'Firmware Hacking',
              'Cryptographic Attacks',
              'Social Engineering',
              'Network Infiltration',
              'Binary Exploitation',
            ].map((s) => (
              <div key={s} className="skill-item">{s}</div>
            ))}
          </div>
        </section>

        {/* Skill Levels */}
        <section>
          <div className="section-label">// threat level assessment</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.8rem', maxWidth: '500px' }}>
            <LevelBar label="Offensive Operations" value={98} delay={0} />
            <LevelBar label="Exploitation Development" value={95} delay={100} />
            <LevelBar label="Reverse Engineering" value={93} delay={200} />
            <LevelBar label="Stealth & Persistence" value={97} delay={300} />
            <LevelBar label="Network Penetration" value={91} delay={400} />
          </div>
        </section>

        {/* Tools */}
        <section>
          <div className="section-label">// arsenal</div>
          <div className="tool-list">
            {[
              'IDA Pro', 'Ghidra', 'GDB-PEDA', 'pwntools', 'Metasploit',
              'Burp Suite', 'Wireshark', 'Frida', 'QEMU', 'LLDB',
              'Volatility', 'Cobalt Strike', 'BloodHound', 'Mimikatz',
              'Nmap', 'Radare2', 'AFL++', 'ROPgadget', 'angr', 'DynamoRIO',
            ].map((t) => (
              <span key={t} className="tool-tag">{t}</span>
            ))}
          </div>
        </section>

        {/* Operations */}
        <section>
          <div className="section-label">// known operations</div>
          <div className="projects-grid">
            {[
              {
                title: 'PHANTOM ROOT',
                desc: 'Kernel-level rootkit bypassing modern EDR solutions on hardened Linux systems. Undetected for 6+ months.',
              },
              {
                title: 'BLACKGATE',
                desc: 'Zero-day exploit chain targeting enterprise VPN infrastructure. Affected 3 major vendors.',
              },
              {
                title: 'SILENTTHREAD',
                desc: 'Advanced persistence mechanism using UEFI firmware implants. Survives full OS reinstall.',
              },
              {
                title: 'VOIDSTRIKE',
                desc: 'Custom C2 framework with encrypted multi-hop routing and automatic payload obfuscation.',
              },
              {
                title: 'ECLIPSE',
                desc: 'Supply chain attack simulation against isolated corporate networks using hardware interdiction.',
              },
              {
                title: 'NULLSECTOR',
                desc: 'Memory corruption exploit enabling remote code execution via heap grooming techniques.',
              },
            ].map((p) => (
              <div key={p.title} className="project-card">
                <div className="project-title">{p.title}</div>
                <div className="project-desc">{p.desc}</div>
              </div>
            ))}
          </div>
        </section>

      </div>

      <div style={{ padding: '1.5rem 4rem', borderTop: '1px solid #0d0d0d', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
        <button className="back-btn" onClick={onBack}>
          ← back to operatives
        </button>
        <span className="footer-text">ORG-END // KERNEL // CLEARANCE: APEX</span>
      </div>
    </div>
  );
}

/* ─── MARTYR PROFILE ─── */
function MartyrPage({ onBack }: { onBack: () => void }) {
  return (
    <div className="profile-page page-enter">
      <NavBar onHome={onBack} />

      <div className="profile-hero">
        <div className="profile-img-wrap">
          <img
            src="https://i.ibb.co/Kpbp6mkP/IMG-9150.jpg"
            alt="Martyr"
          />
        </div>

        <div className="profile-hero-text">
          <div className="profile-hero-id">// operative ID::0x02 — classification: DELTA</div>
          <div className="profile-hero-name">Martyr</div>
          <div className="profile-hero-tagline">
            <span className="status-dot" />
            penetration tester &amp; network security specialist
          </div>
          <p className="profile-hero-desc">
            <span>Martyr</span> specializes in infrastructure penetration testing and red team operations.
            Experienced in compromising enterprise perimeters, conducting OSINT-driven reconnaissance,
            and executing phishing campaigns at scale. A key field operative within{' '}
            <span>ORG-END</span>, responsible for external attack surface assessment
            and social engineering engagements.
          </p>

          <a
            href="https://www.tiktok.com/@martyr.2?_r=1&_t=ZN-968WF87TJ6E"
            target="_blank"
            rel="noopener noreferrer"
            className="contact-btn"
          >
            <span>⬡</span> Contact Martyr
          </a>
        </div>
      </div>

      <div className="profile-content">

        {/* Expertise */}
        <section>
          <div className="section-label">// domains of expertise</div>
          <div className="skill-grid">
            {[
              'Penetration Testing',
              'Network Reconnaissance',
              'OSINT Operations',
              'Phishing Campaigns',
              'Web App Security',
              'Active Directory Attacks',
              'Wireless Security',
              'Red Team Operations',
              'Vulnerability Analysis',
              'Social Engineering',
            ].map((s) => (
              <div key={s} className="skill-item">{s}</div>
            ))}
          </div>
        </section>

        {/* Skill Levels */}
        <section>
          <div className="section-label">// threat level assessment</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.8rem', maxWidth: '500px' }}>
            <LevelBar label="Network Penetration" value={88} delay={0} />
            <LevelBar label="OSINT & Reconnaissance" value={90} delay={100} />
            <LevelBar label="Social Engineering" value={85} delay={200} />
            <LevelBar label="Web Application Attacks" value={82} delay={300} />
            <LevelBar label="Red Team Operations" value={84} delay={400} />
          </div>
        </section>

        {/* Tools */}
        <section>
          <div className="section-label">// arsenal</div>
          <div className="tool-list">
            {[
              'Nmap', 'Metasploit', 'Burp Suite', 'Nikto', 'Hydra',
              'Aircrack-ng', 'Maltego', 'Shodan', 'TheHarvester',
              'SQLmap', 'Responder', 'CrackMapExec', 'Nessus',
              'Recon-ng', 'Bettercap', 'Wireshark', 'John the Ripper',
            ].map((t) => (
              <span key={t} className="tool-tag">{t}</span>
            ))}
          </div>
        </section>

        {/* Operations */}
        <section>
          <div className="section-label">// known operations</div>
          <div className="projects-grid">
            {[
              {
                title: 'IRONVEIL',
                desc: 'Full perimeter breach of a simulated enterprise environment within 48 hours using chained vulnerabilities.',
              },
              {
                title: 'GHOSTNET',
                desc: 'Wireless infiltration operation targeting WPA3 networks using side-channel timing attacks.',
              },
              {
                title: 'DEEPFISH',
                desc: 'Large-scale spear-phishing campaign with 73% credential capture rate on hardened targets.',
              },
              {
                title: 'REDSHIFT',
                desc: 'Active Directory domain takeover via Kerberoasting and LDAP enumeration on Fortune-500 environment.',
              },
            ].map((p) => (
              <div key={p.title} className="project-card">
                <div className="project-title">{p.title}</div>
                <div className="project-desc">{p.desc}</div>
              </div>
            ))}
          </div>
        </section>

      </div>

      <div style={{ padding: '1.5rem 4rem', borderTop: '1px solid #0d0d0d', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
        <button className="back-btn" onClick={onBack}>
          ← back to operatives
        </button>
        <span className="footer-text">ORG-END // MARTYR // CLEARANCE: DELTA</span>
      </div>
    </div>
  );
}

/* ─── GLITCH OVERLAY COMPONENT ─── */
function GlitchOverlay({ active, stripes }: {
  active: boolean;
  stripes: { top: string; height: string; opacity: number; offset: string }[];
}) {
  if (!active) return null;

  return (
    <div className="glitch-overlay" style={{ animation: 'glitch-bg 0.7s steps(1) forwards' }}>
      <style>{`
        @keyframes glitch-bg {
          0%   { background: rgba(0,0,0,0); }
          5%   { background: rgba(0,0,0,0.95); }
          15%  { background: rgba(0,0,0,0.2); }
          25%  { background: rgba(0,0,0,0.9); }
          40%  { background: rgba(0,0,0,0.1); }
          55%  { background: rgba(0,0,0,0.85); }
          70%  { background: rgba(0,0,0,0.15); }
          85%  { background: rgba(0,0,0,0.95); }
          100% { background: rgba(0,0,0,0); }
        }
        @keyframes stripe-flash {
          0%   { opacity: 0; transform: translateX(0); }
          20%  { opacity: 1; transform: translateX(var(--offset)); }
          40%  { opacity: 0; transform: translateX(0); }
          60%  { opacity: 0.8; transform: translateX(calc(var(--offset) * -1)); }
          80%  { opacity: 0; transform: translateX(0); }
          100% { opacity: 0; }
        }
      `}</style>
      {stripes.map((s, i) => (
        <div
          key={i}
          className="glitch-stripe"
          style={{
            top: s.top,
            height: s.height,
            '--offset': s.offset,
            animation: `stripe-flash ${0.3 + Math.random() * 0.4}s steps(1) ${i * 0.02}s forwards`,
          } as React.CSSProperties}
        />
      ))}
    </div>
  );
}

/* ─── ROOT APP ─── */
export default function App() {
  const [page, setPage] = useState<Page>('entry');
  const [entryVisible, setEntryVisible] = useState(true);
  const { isGlitching, stripes, runGlitch } = useGlitchTransition();

  const navigate = useCallback(async (target: Page) => {
    await runGlitch();
    setPage(target);
    window.scrollTo({ top: 0 });
  }, [runGlitch]);

  const handleEnter = async () => {
    await runGlitch();
    setEntryVisible(false);
    setPage('home');
  };

  return (
    <>
      {/* Global overlay effects */}
      <div className="noise-overlay" />
      <div className="scanlines" />

      {/* Glitch transition */}
      <GlitchOverlay active={isGlitching} stripes={stripes} />

      {/* Entry screen */}
      {entryVisible && page === 'entry' && (
        <EntryScreen onEnter={handleEnter} />
      )}

      {/* Main content */}
      {page !== 'entry' && (
        <>
          {page === 'home' && (
            <HomePage
              onSelect={(p) => navigate(p)}
            />
          )}
          {page === 'kernel' && (
            <KernelPage onBack={() => navigate('home')} />
          )}
          {page === 'martyr' && (
            <MartyrPage onBack={() => navigate('home')} />
          )}
        </>
      )}
    </>
  );
}
